<?php
    /**
     * @package WP Auto Tags
     * @version 1.0.0
     */
    /*
     Plugin Name: WP Auto Tags
     Plugin URI: http://longinus.cn
     Description: WP Auto Tags
     Author: Kinky Longinus Dean 
     Version: 1.0.0
     Author URI: http://longinus.cn
     */
    
    
    class wp_auto_tags
    {
        
        public function request_by_other($remote_server,$post_string)
        {
            $context = array(
                             'http'=>array(
                                           'method'=>'POST',
                                           'header'=>'Content-type: application/x-www-form-urlencoded'."\r\n".
                                           'User-Agent : Mozilla'."\r\n".
                                           'Content-length: '.strlen($post_string)+8,
                                           'content'=> $post_string)
                             );
            $stream_context = stream_context_create($context);
            $data = file_get_contents($remote_server,FALSE,$stream_context);
            return $data;
        }
        
        public function get_tags_from_remote($title,$content)
        {
            $title=urlencode($title);
            $content=urlencode($content);
            $data = $this->request_by_other('http://keyword.discuz.com/related_kw.html',"title=$title&content=$content&ics=utf-8&ocs=utf-8");
            
            if($data) { 
                $parser = xml_parser_create();
                xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0); 
                xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1); 
                xml_parse_into_struct($parser, $data, $values, $index);
                xml_parser_free($parser);    
                $kws = array(); 
                foreach($values as $valuearray) { 
                    if(in_array($valuearray['tag'],array('kw','ekw'))) {
                        $kws[] = $valuearray['value'];//编码转换    
                    }    
                }
                
                return $kws;
            }
            else
            {
                echo '<p>远程数据获取失败</p>';
            }
        }
        
        public function auto_tags($post_ID)
        {
            $post_ID=(int) $post_ID;
            $post=get_post( $post_ID ) ;
            
            if(! $post || 'page' == $post->post_type)
                return false;
            
            $post_title = $post -> post_title;
            $post_content = $post -> post_content;
            $post_content = preg_replace("/\[.+?\]\n\r/U",'',$post_content);
            
            $kws = array();
            $kws = $this->get_tags_from_remote($post_title,$post_content);
            if($kws)
            {
                $tags=implode(',',$kws);
                echo '<p>为标题为 '.$post_title.' 的文章获取了tags '.$tags.'</p>';
                wp_add_post_tags($post_ID,$tags);
            }
            else
            {
                echo '<p>为标题为 '.$post_title.' 的文章获取tags失败</p>';
            }
        }
        
        
        
        function wp_auto_tags_options()
        {
            
    ?>
<div class="wrap">
<h2 id="write-post">WP Auto Tags设置 &hellip;</h2>


</p>
</form>


<h2 id="write-post">批量采集：	</h2>
<p>
<b>从搜索引擎获取文章标题 或 标签和标题的相关关键字并自动添加为文章标签</b> 
</p>
<?php
	global $wpdb;
	$max_id=$wpdb->get_var("SELECT ID FROM $wpdb->posts ORDER BY ID DESC LIMIT 1");
	$min_id=$wpdb->get_var("SELECT ID FROM $wpdb->posts ORDER BY ID ASC LIMIT 1");
	
	if( isset($_POST['do']) && 'bulk' == $_POST['do'] )
	{
        $start_id=(int) $_POST['start_id'];
        $end_id=(int) $_POST['end_id'];
        
        $ids=$wpdb->get_col("SELECT ID FROM $wpdb->posts WHERE post_status='publish' and post_type='post' and ID>=$start_id and ID<=$end_id",0);
        
		foreach( (array) $ids as $id )
		{
			echo '<p>正在处理ID为'.$id.'的文章......</p>';
			$this->auto_tags($id );
			
		}
		echo '<p>ID从'.$start_id.'到'.$end_id .'的文章处理完毕。</p>';
	}
    ?>

<p>
<form name="form1" action="<?php echo $_SERVER['PHP_SELF']; ?>?page=wp-auto-tags/wp-auto-tags.php" method="post">

起始文章ID:
<input type="text" name="start_id" value="" />

结束文章ID:
<input type="text" name="end_id" value="" />
</p>

<input type="hidden" name="do" value="bulk">

<p class="submit">

<input type="submit" name="submit" value="开始" />
</p>

</form>
</p>	

</div>		
<?php		
	}
	
	
	function wp_auto_tags_memu() 
	{
        add_submenu_page('tools.php','WP Auto Tags设置', 'WP Auto Tags', 8, dirname(__FILE__).'/wp-auto-tags.php',  array(&$this,'wp_auto_tags_options')  );
        
	}
    }
    
    
    $wp_auto_tags=new wp_auto_tags();
    
    
    add_action('admin_menu',array(&$wp_auto_tags, 'wp_auto_tags_memu') );
    
    function auto_add_tags($post_id)
	{
		$post_ID=(int)$post_id;
        $wp_auto_tags=new wp_auto_tags();
        $wp_auto_tags->auto_tags($post_ID);
    }
    
    //只对文章起作用
    if( isset($_POST['post_type'])  &&  ( 'page' != $_POST['post_type'] )  )
    {
        add_action('publish_post','auto_add_tags');
        add_action('edit_post','auto_add_tags');
    }